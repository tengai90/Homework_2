Tema: Programmesanas valodu enciklopedija

Git-adress: https://github.com/tengai90/4_HomeWork_DreamTeam.git

Komandas dalibnieki: 
1) Viktorija Bulvane
2) Diana Kornjeeva
3) Raimonds Fridenbergs
4) Zans-Jans Smulko